<html lang="en"><head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="/static/css/news.css">

    <title></title>
  </head>
  <body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
    <a class="navbar-brand" href="#">NutriViser</a>

    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
      <li class="nav-item active">
        <a class="nav-link" href="/">Home <span class="sr-only">(current)</span></a>
      </li>

    </ul>


    <div class="btn-group" role="group" aria-label="Basic example">
      <a class="nav-link btn btn-light my-2 my-sm-0" href="/account/login">Login</a>
      <a class="nav-link btn btn-outline-light my-2 my-sm-0" href="/account/signup">Sign up</a>
    </div>

  </div>
</nav>

<div class="container">

  <ul class="nav nav-pills">
    <li class="nav-item">
      <a class="nav-link " href="/news">전체</a>
    </li>

      <a class="nav-link active" href="?category=1">About Us</a>

      <a class="nav-link " href="?category=2">건강 분석</a>

      <a class="nav-link " href="?category=3">구독 신청</a>

      <a class="nav-link " href="?category=4">복용 관리</a>

  </ul>


          <div class="row">
            <div class="col-md-6 col-lg-3">
                <div class="card" id="card1">
                    <img class="card-img-top img-fluid" src="https://s3.amazonaws.com/cdn-origin-etr.akc.org/wp-content/uploads/2017/11/13001000/Beagle-On-White-01.jpg">
                    <div class="card-body">
                        <h3 class="card-title">건강 분석</h3>
                        <p class="card-text">문진을 통해 건강을 분석하고 고객 맞춤형 영양제를 추천해드립니다.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="card" id="card2">
                    <img class="card-img-top img-fluid" src="https://s3.amazonaws.com/cdn-origin-etr.akc.org/wp-content/uploads/2017/11/13001000/Beagle-On-White-01.jpg">
                    <div class="card-body">
                        <h3 class="card-title">영양제/스무디 구독</h3>
                        <p class="card-text">추천받은 영양제와 스무디를 간편하게 구독할 수 있습니다.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="card">
                    <img class="card-img-top img-fluid" src="https://s3.amazonaws.com/cdn-origin-etr.akc.org/wp-content/uploads/2017/11/13001000/Beagle-On-White-01.jpg">
                    <div class="card-body">
                        <h3 class="card-title">복용 관리</h3>
                        <p class="card-text">꾸준한 복용을 위해 직접 관리해드립니다.</p>
                    </div>
                </div></div></div>



  <div class="btn-toolbar justify-content-between" role="toolbar" aria-label="Toolbar with button groups">
    <div class="btn-group" role="group" aria-label="First group">
    </div>

  </div>
</div>
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>


</body></html>
